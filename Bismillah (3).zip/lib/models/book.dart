class Book {
  final String title;
  final String author;
  final int year;
  final String imageUrl;
  bool available;

  Book({
    required this.title,
    required this.author,
    required this.year,
    required this.imageUrl,
    this.available = true,
  });
}
