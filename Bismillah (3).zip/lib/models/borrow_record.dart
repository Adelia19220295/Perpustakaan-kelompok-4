import 'package:bismillah/models/book.dart';

class BorrowRecord {
  final String id;
  final Book book;
  final String borrower;
  final DateTime borrowedDate;
  final DateTime returnDate;

  BorrowRecord({
    required this.id,
    required this.book,
    required this.borrower,
    required this.borrowedDate,
    required this.returnDate,
  });

  BorrowRecord copyWith({
    String? id,
    Book? book,
    String? borrower,
    DateTime? borrowedDate,
    DateTime? returnDate,
  }) {
    return BorrowRecord(
      id: id ?? this.id,
      book: book ?? this.book,
      borrower: borrower ?? this.borrower,
      borrowedDate: borrowedDate ?? this.borrowedDate,
      returnDate: returnDate ?? this.returnDate,
    );
  }
}
