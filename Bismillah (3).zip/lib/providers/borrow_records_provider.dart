import 'package:bismillah/models/book.dart';
import 'package:flutter/material.dart';
import '../models/borrow_record.dart';

class BorrowRecordsProvider extends ChangeNotifier {
  final List<BorrowRecord> _borrowRecords = [];

  List<BorrowRecord> get borrowRecords => _borrowRecords;

  void addBorrowRecord(BorrowRecord record) {
    _borrowRecords.add(record);
    notifyListeners();
  }

  void removeBorrowRecord(BorrowRecord record) {
    _borrowRecords.remove(record);
    notifyListeners();
  }

  void updateBorrowRecord(BorrowRecord updatedRecord) {
    final index =
        _borrowRecords.indexWhere((record) => record.id == updatedRecord.id);
    if (index != -1) {
      _borrowRecords[index] = updatedRecord;
      notifyListeners();
    }
  }
}
