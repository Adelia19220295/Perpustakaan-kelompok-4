import 'package:flutter/material.dart';
import '../models/book.dart';

class BookProvider extends ChangeNotifier {
  final List<Book> _books = [
    Book(
      title: 'Bumi',
      author: 'TereLiye',
      year: 2018,
      imageUrl:
          'https://cdn.gramedia.com/uploads/items/img20220830_10560995.jpg',
    ),
    Book(
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      year: 1960,
      imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c',
    ),
    Book(
      title: 'Si Anak Spesial',
      author: 'TereLiye',
      year: 2018,
      imageUrl:
          'https://cdn.gramedia.com/uploads/items/9786025734441_si-anak-spesi.jpg',
    ),
  ];

  List<Book> get books => _books;

  void addBook(Book book) {
    _books.add(book);
    notifyListeners();
  }
}
