import 'package:bismillah/models/borrow_record.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/borrow_records_provider.dart';
import 'providers/book_provider.dart';
import 'screens/home_page.dart';
import 'screens/borrow_history_page.dart';
import 'screens/welcome_page.dart';
import 'screens/add_book_page.dart';
import 'screens/edit_borrow_record_page.dart';

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => BorrowRecordsProvider()),
        ChangeNotifierProvider(create: (_) => BookProvider()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Library App',
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomePage(),
        '/home': (context) => Consumer<BookProvider>(
              builder: (context, bookProvider, child) {
                return HomePage();
              },
            ),
        '/borrow-history': (context) => const BorrowHistoryPage(),
        '/add-book': (context) => const AddBookPage(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/edit-borrow-record') {
          final record = settings.arguments as BorrowRecord;
          return MaterialPageRoute(
            builder: (context) => EditBorrowRecordPage(record: record),
          );
        }
        return null;
      },
    );
  }
}
