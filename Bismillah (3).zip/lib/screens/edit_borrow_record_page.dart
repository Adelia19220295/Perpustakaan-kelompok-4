import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/borrow_record.dart';
import '../providers/borrow_records_provider.dart';

class EditBorrowRecordPage extends StatefulWidget {
  final BorrowRecord record;

  const EditBorrowRecordPage({Key? key, required this.record})
      : super(key: key);

  @override
  _EditBorrowRecordPageState createState() => _EditBorrowRecordPageState();
}

class _EditBorrowRecordPageState extends State<EditBorrowRecordPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _borrowerController;
  late DateTime _returnDate;

  @override
  void initState() {
    super.initState();
    _borrowerController = TextEditingController(text: widget.record.borrower);
    _returnDate = widget.record.returnDate;
  }

  Future<void> _updateRecord() async {
    if (_formKey.currentState!.validate()) {
      final updatedRecord = widget.record.copyWith(
        borrower: _borrowerController.text,
        returnDate: _returnDate,
      );

      Provider.of<BorrowRecordsProvider>(context, listen: false)
          .updateBorrowRecord(updatedRecord);

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: BackButton(),
      appBar: AppBar(
        title: const Text('Edit Riwayat Peminjaman'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _borrowerController,
                decoration: const InputDecoration(labelText: 'Peminjam'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Peminjam tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _updateRecord,
                child: const Text('Update'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
