import 'package:bismillah/screens/edit_borrow_record_page.dart';
import 'package:bismillah/widget/sidebar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/borrow_records_provider.dart';
import '../models/borrow_record.dart';
import '../models/book.dart';

class BorrowHistoryPage extends StatelessWidget {
  const BorrowHistoryPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final borrowHistory =
        Provider.of<BorrowRecordsProvider>(context).borrowRecords;

    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text('Riwayat Peminjaman'),
      ),
      body: ListView.builder(
        itemCount: borrowHistory.length,
        itemBuilder: (context, index) {
          final record = borrowHistory[index];
          return ListTile(
            title: Text(record.book.title), // Fixed
            subtitle: Text('Dipinjam oleh: ${record.borrower}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            EditBorrowRecordPage(record: record),
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    Provider.of<BorrowRecordsProvider>(context, listen: false)
                        .removeBorrowRecord(record); // Fixed
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
