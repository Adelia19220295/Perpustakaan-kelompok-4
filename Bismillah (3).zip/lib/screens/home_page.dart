import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/book_provider.dart';
import '../widget/sidebar.dart';
import 'package:bismillah/screens/book_detail_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final books = Provider.of<BookProvider>(context).books;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Perpustakaan'),
      ),
      body: books.isEmpty
          ? const Center(child: Text('Tidak ada buku'))
          : ListView.builder(
              itemCount: books.length,
              itemBuilder: (context, index) {
                final book = books[index];
                return ListTile(
                  leading: Image.network(
                    book.imageUrl,
                    width: 50,
                    fit: BoxFit.cover,
                  ),
                  title: Text(book.title),
                  subtitle: Text('by ${book.author}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookDetailPage(
                          book: book,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
      drawer: const Sidebar(),
    );
  }
}
