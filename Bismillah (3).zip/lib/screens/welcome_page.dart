import 'package:bismillah/widget/sidebar.dart';
import 'package:flutter/material.dart';

class WelcomePage extends StatelessWidget {
  const WelcomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text('PERPUSTAKAAN SMAN 10'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 200, // Sesuaikan ukuran gambar
              height: 200, // Sesuaikan ukuran gambar
              fit: BoxFit.cover,
            ),
            const Text(
              'Selamat datang di Aplikasi Perpustakaan',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
