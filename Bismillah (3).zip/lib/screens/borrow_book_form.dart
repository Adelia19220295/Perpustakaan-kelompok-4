import 'package:bismillah/widget/sidebar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/book.dart';
import '../models/borrow_record.dart';
import '../providers/borrow_records_provider.dart';

class BorrowBookForm extends StatefulWidget {
  final Book book;

  const BorrowBookForm({Key? key, required this.book}) : super(key: key);

  @override
  _BorrowBookFormState createState() => _BorrowBookFormState();
}

class _BorrowBookFormState extends State<BorrowBookForm> {
  final _formKey = GlobalKey<FormState>();
  final _borrowerController = TextEditingController();

  void _borrowBook() {
    if (_formKey.currentState!.validate()) {
      final newBorrowRecord = BorrowRecord(
        id: UniqueKey().toString(), // Generate a unique ID for the record
        book: widget.book,
        borrower: _borrowerController.text,
        borrowedDate: DateTime.now(),
        returnDate: DateTime.now().add(Duration(days: 14)),
      );

      Provider.of<BorrowRecordsProvider>(context, listen: false)
          .addBorrowRecord(newBorrowRecord);

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Sidebar(),
      appBar: AppBar(
        title: const Text('Pinjam Buku'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _borrowerController,
                decoration: const InputDecoration(labelText: 'Nama Peminjam'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama peminjam tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _borrowBook,
                child: const Text('Pinjam Buku'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
