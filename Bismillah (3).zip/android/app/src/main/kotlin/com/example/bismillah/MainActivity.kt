package com.example.bismillah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
